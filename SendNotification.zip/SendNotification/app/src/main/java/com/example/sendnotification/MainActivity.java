package com.example.sendnotification;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private static final String KEY_TITLE = "title";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_TIME = "time";

    private EditText editTextTitle;
    private EditText editTextMessage;
   // private EditText editTextTime;
    private TextView editTextTime;
    Button mPickTime;
    Context mContext=this;

    private FirebaseFirestore db=FirebaseFirestore.getInstance();

    private List<String> load = new ArrayList<>();//new
    private CollectionReference ref1 = db.collection("users metadata");
    // private CollectionReference ref1 =db.collection("users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextTitle = findViewById(R.id.title);
        editTextMessage = findViewById(R.id.message);
        editTextTime = findViewById(R.id.time);
        //new
        Calendar calendar= Calendar.getInstance();
        final int hour=calendar.get(Calendar.HOUR_OF_DAY);
        final int minute =calendar.get(Calendar.MINUTE);
      //  final int ampm=calendar.get(Calendar.AM_PM);

        mPickTime=(Button)findViewById(R.id.settime);
        mPickTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog= new TimePickerDialog(mContext, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        String ampm;
                        if(hourOfDay>=12){
                            ampm="PM";
                        }
                        else{
                            ampm="AM";
                        }
                        editTextTime.setText(hourOfDay+":"+minute+" "+ampm);
                    }
                },hour,minute,false);
                timePickerDialog.show();
            }
        });

//
        ref1.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                Log.v(TAG, task.toString());
                task.isComplete();
                if (task.isSuccessful()) {
                    int size = task.getResult().getDocuments().size();
                    for (int i = 0; i < size; i++) {
                        Log.v("Harpreet", task.getResult().getDocuments().get(i).get("User Id").toString());
                        String s = task.getResult().getDocuments().get(i).get("User Id").toString();
                        load.add(s);//storing strings in array list
                    }
                }
            }
        }).addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                Log.v(TAG, queryDocumentSnapshots.toString());
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(MainActivity.this, "error", Toast.LENGTH_SHORT).show();
            }
        });


    }

    public void sendnote(View view) {
        String title = editTextTitle.getText().toString();
        String message = editTextMessage.getText().toString();
        String time = editTextTime.getText().toString();

        Map<String, Object> note = new HashMap<>();
        note.put(KEY_TITLE, title);
        note.put(KEY_MESSAGE, message);
        note.put(KEY_TIME, time);

        for (int i = 0; i < load.size(); i++) {
            String s = load.get(i);
            Log.v("Kamal", s);


            db.collection("users").document(s).collection("Notifications").document().set(note)//
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(MainActivity.this, "Notification sent", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                             Log.d(TAG, e.toString());
                        }
                    });

        }
    }
}


